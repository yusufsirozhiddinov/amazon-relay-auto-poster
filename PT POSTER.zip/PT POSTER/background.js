
// Helper to find the load object by ID in the last payload
function findLoadByPartialId(workOpportunities, loadId) {
  for (const key in workOpportunities) {
    const load = workOpportunities[key]; // load object
    if (load.id && load.id.includes(loadId)) {
      return load; // matched load
    }
  }
  return null; // not found
}

function checkAIBookable(workOpportunities) {
  let loads = [];

  function upsertLoad(id, status) {
    const index = loads.findIndex(l => l.id === id);
    if (index !== -1) {
      // update existing
      loads[index].status = status;
    } else {
      // insert new
      loads.push({ id, status });
    }
  }

  for (const key in workOpportunities) {
    const load = workOpportunities[key]; // load object
    if (load.demandSupportEnabled === true) {
      upsertLoad(load.id, load.demandSupportEnabled);
    }
  }

  return loads;
}

function refresher(tabId, token, payload) {
  chrome.scripting.executeScript(
    {
      target: { tabId: tabId },
      func: (csrfToken, payload) => {
        return fetch("https://relay.amazon.com/api/loadboard/search", {
          method: "POST",
          headers: {
            "content-type": "application/json",
            accept: "application/json",
            "x-csrf-token": csrfToken,
            origin: "https://relay.amazon.com",
            referer: "https://relay.amazon.com/loadboard/search"
          },
          body: JSON.stringify(payload),
          credentials: "include"
        })
          .then(async (res) => {
            const text = await res.text();
            try {
              return { ok: res.ok, status: res.status, data: JSON.parse(text) };
            } catch {
              return { ok: res.ok, status: res.status, raw: text };
            }
          })
          .catch((err) => ({ ok: false, error: err.message }));
      },
      args: [token, payload]
    },
    (results) => {
      const result = results?.[0]?.result;
      if (result?.ok) {
        let AIBookableList = checkAIBookable(result.data.workOpportunities);
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, { action: "showAI", statusList: AIBookableList});
        });
      } else {
        console.error("[background] /search failed:", result);
      }
    }
  );
}




chrome.action.onClicked.addListener(() => {
  const width = 400;
  const height = 600;

  chrome.windows.create({
    url: chrome.runtime.getURL("popup.html"),
    type: "popup",
    width: width,
    height: height,
    top: Math.round((screen.height - height) / 2),
    left: Math.round((screen.width - width) / 2)
  });
});




// ---- Store last payload per tab ----
const lastPayloads = {};

// ---- Monitor search requests ----
chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
        if (details.method !== "POST") return;
        if (!details.url.includes("/api/loadboard/search")) return;

        try {
            const raw = details.requestBody?.raw?.[0]?.bytes;
            if (!raw) return;
            const text = new TextDecoder("utf-8").decode(raw);
            lastPayloads[details.tabId] = JSON.parse(text);
        } catch (e) {
            console.error("[background] Failed to parse payload:", e);
        }
    },
    { urls: ["https://relay.amazon.com/api/loadboard/search*"] },
    ["requestBody"]
);





function extractLoadInfo(load) {
  if (!load) return null;

  const stops = Array.isArray(load.loads) ? load.loads.length + 1 : load.stopCount || 1;

  const payoutRaw = load.payout?.value || 0;
  const milesRaw = load.totalDistance?.value || 1; // avoid division by zero

  // Price per mile truncated to 2 decimals
  const ratePerMile = Math.floor((payoutRaw / milesRaw) * 100) / 100;

  return {
    // Pickup
    pickupCity: load.startLocation?.city || null,
    pickupState: load.startLocation?.state || null,
    pickupLatitude: load.startLocation?.latitude || null,
    pickupLongitude: load.startLocation?.longitude || null,
    pickupTime: load.firstPickupTime || null,

    // Delivery
    deliveryCity: load.endLocation?.city || null,
    deliveryState: load.endLocation?.state || null,
    deliveryLatitude: load.endLocation?.latitude || null,
    deliveryLongitude: load.endLocation?.longitude || null,
    deliveryTime: load.lastDeliveryTime || null,

    // Other info
    payout: Math.trunc(payoutRaw),
    stops: stops,
    miles: Math.trunc(milesRaw),
    ratePerMile: ratePerMile
  };
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "COPY_LOAD_ID") return true;

  const tabId = sender.tab?.id;
  const payload = lastPayloads[tabId];
  const token = msg.token;
  const loadId = msg.loadId; // the ID you got from content.js

  if (!payload) return console.warn("[background] No payload for tab", tabId);
  if (!token) return console.warn("[background] No CSRF token received");
  if (!loadId) return console.warn("[background] No load ID received");



  // ---- 2️⃣ Execute the search request in tab context using the payload ----
  chrome.scripting.executeScript(
    {
      target: { tabId: tabId },
      func: (csrfToken, payload) => {
        return fetch("https://relay.amazon.com/api/loadboard/search", {
          method: "POST",
          headers: {
            "content-type": "application/json",
            accept: "application/json",
            "x-csrf-token": csrfToken,
            origin: "https://relay.amazon.com",
            referer: "https://relay.amazon.com/loadboard/search"
          },
          body: JSON.stringify(payload),
          credentials: "include"
        })
          .then(async (res) => {
            const text = await res.text();
            try {
              return { ok: res.ok, status: res.status, data: JSON.parse(text) };
            } catch {
              return { ok: res.ok, status: res.status, raw: text };
            }
          })
          .catch((err) => ({ ok: false, error: err.message }));
      },
      args: [token, payload]
    },
    (results) => {
      const result = results?.[0]?.result;
      if (result?.ok) {
        const matchedLoad = findLoadByPartialId(result.data.workOpportunities, loadId);

        const rawInfo = extractLoadInfo(matchedLoad);
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, { action: "COPY_TO_CLIPBOARD", data: JSON.stringify(rawInfo, null, 2) });
        });
        let AIBookableList = checkAIBookable(result.data.workOpportunities);
        console.log(AIBookableList);
        // chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        //     chrome.tabs.sendMessage(tabs[0].id, { action: "showAI", statusList: AIBookableList});
        // });
      } else {
        console.error("[background] /search failed:", result);
      }
    }
  );

  return true;
});
