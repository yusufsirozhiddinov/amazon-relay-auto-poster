let meta = document.querySelector('meta[name="x-owp-csrf-token"]');
let csrf = meta ? meta.getAttribute("content") : null;
// robust isToday that doesn't rely on fragile Date parsing of timezone abbreviations
function isWithin12Hours(timeString) {
  const parts = timeString.trim().split(" ");
  const tz = parts.pop(); 
  const [hourStr, minuteStr] = parts.pop().split(":");
  const day = parseInt(parts.pop(), 10); 
  const month = parts.pop(); 
  parts.pop(); // remove day-of-week

  const tzOffsets = {
    CDT: -5 * 60,
    EDT: -4 * 60,
    MDT: -6 * 60,
    PDT: -7 * 60
  };

  if (!(tz in tzOffsets)) {
    throw new Error("Unsupported timezone: " + tz);
  }

  const monthMap = {
    Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5,
    Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11
  };

  const monthIndex = monthMap[month];
  const year = new Date().getFullYear();

  const targetUtc = Date.UTC(
    year,
    monthIndex,
    day,
    parseInt(hourStr, 10),
    parseInt(minuteStr, 10)
  ) - tzOffsets[tz] * 60 * 1000;

  const nowUtc = Date.now();
  const diff = targetUtc - nowUtc;

  if (diff < 0) return false;
  return diff <= 12 * 60 * 60 * 1000;
}

function checkAndDisable(timeString) {
  const btn = document.getElementById("rlb-book-btn");
  if (!btn) return;

  if (!isWithin12Hours(timeString)) {
    btn.disabled = true;
    btn.style.backgroundColor = "gray";
    btn.style.color = "white";
    btn.style.cursor = "not-allowed";
    btn.style.opacity = "0.6";
    btn.textContent = "⚠️ BOOK"; // updated text with warning

    // Only inject checkbox if load is more than 12 hours away
    injectFutureLoadCheckbox(timeString);
  } else {
    btn.disabled = false;
    btn.style.backgroundColor = "";
    btn.style.color = "";
    btn.style.cursor = "";
    btn.style.opacity = "";
    btn.textContent = "BOOK"; // reset text
  }
}

function injectFutureLoadCheckbox(timeString) {
  // Only inject if button is disabled (future load)
  const btn = document.getElementById("rlb-book-btn");
  if (!btn || !btn.disabled) return;

  const container = document.querySelector(".css-8ubre6");
  if (!container) return;

  // Prevent double injection
  if (document.getElementById("future-load-checkbox")) return;

  // Create checkbox + label
  const label = document.createElement("label");
  label.style.display = "flex";
  label.style.alignItems = "center";
  label.style.gap = "10px";
  label.style.fontSize = "18px";
  label.style.fontWeight = "600";
  label.style.marginTop = "12px";
  label.style.cursor = "pointer";

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.id = "future-load-checkbox";
  checkbox.style.width = "22px";
  checkbox.style.height = "22px";
  checkbox.style.cursor = "pointer";

  const text = document.createTextNode("BOOK FUTURE LOAD");

  label.appendChild(checkbox);
  label.appendChild(text);
  container.appendChild(label);

  // Handle checkbox toggle
  checkbox.addEventListener("change", () => {
    if (checkbox.checked) {
      // Force enable and reset styles
      btn.disabled = false;
      btn.style.backgroundColor = "";
      btn.style.color = "";
      btn.style.cursor = "";
      btn.style.opacity = "";
      btn.textContent = "BOOK"; // reset text
    } else {
      // Re-run the check logic
      checkAndDisable(timeString);
    }
  });
}

// 🔹 Example usage
const loadTime = "Wed Sep 24 08:00 EDT"; // replace with your dynamic time string
checkAndDisable(loadTime);




chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "COPY_TO_CLIPBOARD") {
    navigator.clipboard.writeText(message.data)
      .then(() => console.log("✅ Copied to clipboard!"))
      .catch(err => console.error("❌ Failed to copy: ", err));
    let btn = document.querySelector(".my-copy-btn");
    btn.innerHTML = `Copied!`
  }
  return true;
});

function warner() {
  // Loop over all main blocks

}

let firstEntity = null;

function getInfo() {
  const entityDivs = document.querySelectorAll(".entity-id");
  if (entityDivs.length < 2) return null; // no second element

  const secondDiv = entityDivs[0]; // index 1 = second element
  const p = secondDiv.querySelector("p");
  if (!p) return null;

  const text = p.textContent.trim(); // e.g. "Load...43dd0209"
  const parts = text.split("...");
  return parts.length > 1 ? parts[1] : null;
}

// Create copy button
function createCopyButton() {
  const btn = document.createElement("button");
  btn.innerHTML = `
    Copy`;
  btn.style.marginLeft = "5px";
  btn.style.width = "110px";
  btn.style.height = "40px";
  btn.style.border = "none";
  btn.style.borderRadius = "10px";
  btn.style.backgroundColor = "#09FF74";
  btn.style.cursor = "pointer";
  btn.classList.add("my-copy-btn");

  btn.onclick = async () => {
    const loadId = getInfo();
    try {
      chrome.runtime.sendMessage({ type: "COPY_LOAD_ID", loadId: loadId, token: csrf }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn("Message failed:", chrome.runtime.lastError.message);
        } else {
          console.log("Background response:", response);
        }
      });
    } catch (err) {
      console.error("SendMessage failed:", err);
    }
    console.log("🧃 Scraped CSRF (via content script):", csrf);
  };

  return btn;
}

// Attach listener and inject button
function attachListener() {
  const entities = Array.from(document.querySelectorAll(".entity-id")).filter(
    (el) => el.offsetParent !== null
  );
  if (!entities.length) return;

  const first = entities[0];
  if (first === firstEntity) return;
  firstEntity = first;

  first.style.cursor = "pointer";
  first.addEventListener("click", (e) => {
    if (e.target !== first) return;
    navigator.clipboard.writeText(first.innerText.trim());
  });

  const allDivs = document.querySelectorAll("div.css-1q48g4q");

  // 2️⃣ Pick the SECOND one (index 1)
  const targetDiv = allDivs[1];
  if (!targetDiv) {
    console.error("Target div not found!");
    return;
  }
  if (targetDiv) {
    const btn = createCopyButton();
    // 4️⃣ Insert BEFORE the first existing button
    const firstBtn = targetDiv.querySelector("p.css-1nws0dp");
    targetDiv.insertBefore(btn, firstBtn);
    document.querySelectorAll(".css-5e70kp").forEach(block => {
      // Walk down the full infrastructure
      const outerDiv = block.querySelector(":scope > div:nth-child(2)");
      const dateP = outerDiv?.querySelector(":scope > p.css-1maqsxd.css-1gmvhuf");
      const innerDiv = dateP?.querySelector(":scope > div.css-163ns6o");
      const dateSpan = innerDiv?.querySelector(":scope > span.wo-card-header__components");

    });
  }
  // Walk every block and apply styles if NOT today
  document.querySelectorAll(".css-5e70kp").forEach(block => {
    try {
      // walk exactly as your architecture
      const outerDiv = block.querySelector(":scope > div:nth-child(2)");
      const dateP = outerDiv?.querySelector(":scope > p.css-1maqsxd.css-1gmvhuf");
      const innerDiv = dateP?.querySelector(":scope > div.css-163ns6o");
      const dateSpan = innerDiv?.querySelector(":scope > span.wo-card-header__components");

      if (!dateSpan) return; // nothing to do for this block

      const dateText = dateSpan.textContent.trim();
      console.log(dateText);
      // DEBUG (uncomment to inspect): console.log(dateText, isTodayRobust(dateText))
      checkAndDisable(dateText);
      injectFutureLoadCheckbox(dateText);

    } catch (err) {
      console.error("Error processing block:", err);
    }
  });
}

// Observe DOM
const observer = new MutationObserver(() => attachListener());
observer.observe(document.body, { childList: true, subtree: true });
attachListener();





