// Adjust time based on timezone abbreviation in the string

// State normalizer: always returns abbreviation
function convertState(input) {
  const states = {
    "Alabama": "AL", "Alaska": "AK", "Arizona": "AZ", "Arkansas": "AR",
    "California": "CA", "Colorado": "CO", "Connecticut": "CT", "Delaware": "DE",
    "Florida": "FL", "Georgia": "GA", "Hawaii": "HI", "Idaho": "ID",
    "Illinois": "IL", "Indiana": "IN", "Iowa": "IA", "Kansas": "KS",
    "Kentucky": "KY", "Louisiana": "LA", "Maine": "ME", "Maryland": "MD",
    "Massachusetts": "MA", "Michigan": "MI", "Minnesota": "MN", "Mississippi": "MS",
    "Missouri": "MO", "Montana": "MT", "Nebraska": "NE", "Nevada": "NV",
    "New Hampshire": "NH", "New Jersey": "NJ", "New Mexico": "NM", "New York": "NY",
    "North Carolina": "NC", "North Dakota": "ND", "Ohio": "OH", "Oklahoma": "OK",
    "Oregon": "OR", "Pennsylvania": "PA", "Rhode Island": "RI", "South Carolina": "SC",
    "South Dakota": "SD", "Tennessee": "TN", "Texas": "TX", "Utah": "UT",
    "Vermont": "VT", "Virginia": "VA", "Washington": "WA", "West Virginia": "WV",
    "Wisconsin": "WI", "Wyoming": "WY"
  };

  const normalized = input.trim();

  // If input matches full name → return abbreviation
  if (states[normalized]) {
    return states[normalized];
  }

  // If input is already abbreviation → keep it uppercase
  const abbr = normalized.toUpperCase();
  if (Object.values(states).includes(abbr)) {
    return abbr;
  }

  // Not matched → return unchanged
  return input;
}

// ----------------------------
// Utility Functions
// ----------------------------
// Updated formatLoad

// City normalizer: always returns abbreviated form
function convertCityName(city) {
  const replacements = {
    "MOUNT": "MT.",
    "SAINT": "ST."
  };

  const parts = city.toUpperCase().split(" ");

  if (replacements[parts[0]]) {
    parts[0] = replacements[parts[0]];
  }
  // if it's already "MT." or "ST." → stays unchanged

  return parts.join(" ");
}
let dotInterval;

// ----------------------------
// Animate status with dots
// ----------------------------
function animateStatus(message, color = "black") {
  const outputDiv = document.getElementById("output");
  let dots = 0;
  clearInterval(dotInterval);
  outputDiv.style.color = color;
  outputDiv.style.fontSize = "16px";
  outputDiv.style.lineHeight = "1.5";
  outputDiv.style.padding = "5px";

  dotInterval = setInterval(() => {
    dots = (dots + 1) % 4; // 0..3 dots
    outputDiv.innerHTML = `<strong>${message}${".".repeat(dots)}</strong>`;
  }, 500);
}

// ----------------------------
// Geocoding cache
// ----------------------------
const cityCache = {};
async function getCoordinates(city, state) {
  const key = `${city.toUpperCase()},${state.toUpperCase()}`;
  if (cityCache[key]) return cityCache[key];

  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
        city + ", " + state
      )}`,
      {
        headers: { "User-Agent": "LoadParser/1.0" },
      }
    );
    const data = await res.json();
    if (data.length > 0) {
      cityCache[key] = {
        lat: parseFloat(data[0].lat),
        lon: parseFloat(data[0].lon),
      };
      return cityCache[key];
    }
  } catch (err) {
    console.error("Geocoding failed:", err);
  }
  return { lat: null, lon: null };
}

// timeStr: original string like "Sun Sep 7 00:07 CDT"
// type: "pickup" or "delivery" to apply -1 or +1 minute

// ----------------------------
// CSRF Token
// ----------------------------
function getToken(callback) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript(
      {
        target: { tabId: tabs[0].id },
        function: () => {
          const metaTag = document.querySelector(
            "meta[name='x-owp-csrf-token']"
          );
          return metaTag ? metaTag.getAttribute("content") : null;
        },
      },
      (results) => {
        const token = results?.[0]?.result;
        callback(token);
      }
    );
  });
}

// ----------------------------
// Format button listener
// ----------------------------
document.getElementById("formatBtn").addEventListener("click", async () => {
  const rawText = document.getElementById("inputText").value;

  const load = JSON.parse(rawText);
    // Create variables dynamically
    const {
      pickupCity,
      pickupState,
      pickupLatitude,
      pickupLongitude,
      pickupTime,
      deliveryCity,
      deliveryState,
      deliveryLatitude,
      deliveryLongitude,
      deliveryTime,
      payout,
      stops,
      miles,
      ratePerMile
    } = load;


  window.currentLoad = load;
  showLoadOutput(load); // show formatted load

    // Show payout and rate input fields
    const payoutEditor = document.getElementById("payoutEditor");
    payoutEditor.style.display = "block";
    document.getElementById("payoutInput").value = load.payout || 0;
    document.getElementById("rateInput").value = load.ratePerMile || 0;

    // Update global load when inputs change
    document.getElementById("payoutInput").addEventListener("input", (e) => {
      window.currentLoad.totalPrice = parseFloat(e.target.value) || 0;
    });
    document.getElementById("rateInput").addEventListener("input", (e) => {
      window.currentLoad.ratePerMile = parseFloat(e.target.value) || 0;
    });
});

// ----------------------------
// Convert time string to CDT format
// ----------------------------
function adjustTimeByOneMinute(isoStr, type = "pickup") {
  const date = new Date(isoStr);
  if (type === "pickup") date.setMinutes(date.getMinutes() - 10);
  if (type === "delivery") date.setMinutes(date.getMinutes() + 1);
  return date.toISOString();
}

// ----------------------------
// Stop animation and show load info
// ----------------------------
function showLoadOutput(load, status = "idle") {
  const outputDiv = document.getElementById("output");
  let color = "black";
  if (status === "success") color = "#28a745";
  if (status === "error") color = "red";

outputDiv.innerHTML = `
  <div style="
    font-family: 'Arial', sans-serif;
    font-size: 12px;
    line-height: 1;
    color: ${color};
  ">
    <strong>Stops:</strong> ${load.stops}<br>
    <strong>Pick up address:</strong> ${load.pickupCity}, ${load.pickupState}<br>
    <strong>Delivery address:</strong> ${load.deliveryCity}, ${load.deliveryState}<br>
    <strong>Total price:</strong> $${load.payout}<br>
    <strong>Rate per mile:</strong> $${load.ratePerMile}<br>
    <strong>Total miles:</strong> ${load.miles} mi
  </div>
`;
}

// ----------------------------
// Build Upsert Body (with safe values)
// ----------------------------
async function buildUpsertBody(load, shiftHours = 0) {
  // Optionally destructure variables if needed
const {
  pickupCity,
  pickupState,
  pickupLatitude,
  pickupLongitude,
  pickupTime,
  deliveryCity,
  deliveryState,
  deliveryLatitude,
  deliveryLongitude,
  deliveryTime,
  payout,
  stops,
  miles,
  ratePerMile
} = load;

    // --- Safe values from inputs ---
  let payoutInput = ((parseFloat(document.getElementById("payoutInput").value) - 1).toFixed(2)) || payout.toString();
  let rateInput = ((parseFloat(document.getElementById("rateInput").value) - 0.01).toFixed(2)) || ratePerMile.toFixed(2);


  const minDistanceValue = Math.floor(miles - 10); // min miles
  const maxDistanceValue = Math.ceil(miles + 10);  // max miles

  // --- Dropdowns ---
  const driverType = document.getElementById("driverType").value;
  const equipmentType = document.getElementById("equipmentType").value;
  const pickupTimeISO = adjustTimeByOneMinute(pickupTime, "pickup"); // now includes +5h
  const deliveryTimeISO = adjustTimeByOneMinute(deliveryTime, "delivery");
  // --- Equipment JSON ---
  let visibleEquipmentTypes = "";
  let equipmentTypes = [];

  if (equipmentType === "FIFTY_THREE_FOOT_TRUCK") {
    visibleEquipmentTypes = "FIFTY_THREE_FOOT_TRUCK";
    equipmentTypes = [
      "FIFTY_THREE_FOOT_TRUCK",
      "SKIRTED_FIFTY_THREE_FOOT_TRUCK",
      "FIFTY_THREE_FOOT_DRY_VAN",
      "FIFTY_THREE_FOOT_A5_AIR_TRAILER",
      "FORTY_FIVE_FOOT_TRUCK",
    ];
  } else if (equipmentType === "FIFTY_THREE_FOOT_CONTAINER") {
    visibleEquipmentTypes = "FIFTY_THREE_FOOT_CONTAINER";
    equipmentTypes = ["FIFTY_THREE_FOOT_CONTAINER"];
  }
  return {
  runType: "ONE_WAY",
  originCityInfo: {
    name: convertCityName(pickupCity),
    stateCode: convertState(load.pickupState),
    country: "US",
    latitude: pickupLatitude,
    longitude: pickupLongitude,
    displayValue: `${convertCityName(pickupCity)}, ${convertState(pickupState)}`,
    isCityLive: false,
    isAnywhere: false,
    uniqueKey: `${pickupLatitude}${pickupCity}`,
  },
  originCityRadius: { value: 15, unit: "mi" },
  destinationCityInfo: null,
  destinationCityRadius: { value: 25, unit: "mi" },
  startTime: pickupTimeISO,
  endTime: deliveryTimeISO,
  distanceOrDuration: "DISTANCE",
  minDistance: { value: minDistanceValue, unit: "mi" },
  maxDistance: { value: maxDistanceValue, unit: "mi" },
  driverTypes: [driverType],
  payoutType: "FLAT_RATE",
  totalCost: { value: payoutInput, unit: "USD" },
  costPerDistance: {
    value: rateInput,
    currencyUnit: "USD",
    distanceUnit: "mi",
  },
  visibleProvidedTrailerType: "AMAZON_PROVIDED",
  providedTrailerType: "AMAZON_PROVIDED",
  visibleEquipmentTypes,
  equipmentTypes,
  maxNumberOfStops: stops,
  minPickUpBufferInMinutes: "5",
  exclusionCityList: [],
  endLocationList: [
    {
      name: convertCityName(deliveryCity),
      stateCode: convertState(deliveryState),
      country: "US",
      latitude: deliveryLatitude,
      longitude: deliveryLongitude,
      displayValue: `${convertCityName(deliveryCity)}, ${convertState(deliveryState)}`,
      uniqueKey: `${deliveryLatitude}${deliveryCity}`,
    },
  ],
  endRegionList: [],
  supplyDriverIdList: [],
  supplyTransientDriverIdList: [],
  loadingTypeList: ["LIVE"],
  matchingDemands: [],
  matchingWork: 0,
  isCheckingMatchingWork: false,
  isMatchingWorkLoaded: false,
  auditMetaData: { suggestedCostPerDistance: null, matchOutlookScore: "LOW" },
  patOrderContext: null,
  cancellationDetails: null,
};

}

// ----------------------------
// Upsert button listener
// ----------------------------
document.getElementById("upsertBtn").addEventListener("click", async () => {
const rawText = document.getElementById("inputText").value;

// Parse the JSON from input
const load = JSON.parse(rawText);

  const body = await buildUpsertBody(load);

  getToken((csrfToken) => {
    if (!csrfToken) {
      clearInterval(dotInterval);
      document.getElementById("output").textContent =
        "❌ CSRF token not found. Reload Amazon Relay.";
      document.getElementById("output").style.color = "red";
      return;
    }



// Send it via executeScript
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  chrome.scripting.executeScript(
    {
      target: { tabId: tabs[0].id },
      func: (csrfToken, body) => {
        return fetch(
          "https://relay.amazon.com/api/loadboard/orders/upsert",
          {
            method: "POST",
            headers: {
              "content-type": "application/json",
              accept: "application/json",
              "x-csrf-token": csrfToken,
              origin: "https://relay.amazon.com",
              referer: "https://relay.amazon.com/loadboard/search",
            },
            body: JSON.stringify(body), // <- use parsed load from input
            credentials: "include",
          }
        )
          .then(async (res) => {
            const text = await res.text();
            try {
              return {
                ok: res.ok,
                status: res.status,
                data: JSON.parse(text),
              };
            } catch {
              return { ok: res.ok, status: res.status, raw: text };
            }
          })
          .catch((err) => ({ ok: false, error: err.message }));
      },
      args: [csrfToken, body], // <- pass load from input here
    },
    (results) => {
      const result = results?.[0]?.result;
      clearInterval(dotInterval);

      if (result?.ok) {
        document.getElementById("output").textContent = "DONE";
        document.getElementById("output").style.color = "green";
        document.getElementById("output").style.fontWeight = 600;
        setTimeout(() => showLoadOutput(window.currentLoad, "success"), 1000);
      } else {
        document.getElementById("output").textContent = "❌ Failed to put post!";
        document.getElementById("output").style.color = "red";
        console.error("Upsert failed:", result);
      }
    }
  );
});
  });
});
